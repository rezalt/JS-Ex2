/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */





window.addEventListener("load", function ()
{
    TaskOne();
    TaskTwo();
    TaskThree();
    TaskFour();
    console.log("asdasd");
});



function Person(f, l, p, m)
{
    this.firstName = f;
    this.lastName = l;
    this.phone = p;
    this.mail = m;
}

function TaskOne()
{

    var list = document.getElementsByTagName("div");
    var i;
    for (i = 0; i < list.length; i++)
    {
        list[i].style.backgroundColor = "red";

    }
}

function TaskTwo()
{

    var PersonsArray = [new Person("John", "Arne", 56462763, "Ja@johnarne.ja"), new Person("Not", "John", 6685646, "nj@notjohn.nj")];
    PersonsArray.push(new Person("aPerson", "Jensen", 123456789, "ApJ@gmail.com"));

    var tp = document.getElementById("TablePers").getElementsByTagName("tbody")[0];

    for (var i = 0; i < PersonsArray.length; i++)
    {

        var newRow = tp.insertRow(i);
        var CellFName = newRow.insertCell(0);
        var CellLName = newRow.insertCell(1);
        var CellPhone = newRow.insertCell(2);
        var CellMail = newRow.insertCell(3);

        CellFName.innerHTML = PersonsArray[i].firstName;
        CellLName.innerHTML = PersonsArray[i].lastName;
        CellPhone.innerHTML = PersonsArray[i].phone;
        CellMail.innerHTML = PersonsArray[i].mail;

        (function (i) {
            tp.getElementsByTagName("tr")[i].addEventListener("click", function () {
                alert(PersonsArray[i].mail);
            });
        })(i);
    }
    ;
}

function TaskThree()
{

    var div1 = document.getElementById("task3-1");
    var div2 = document.getElementById("task3-2");
    var div3 = document.getElementById("task3-3");

    div1.style.width = "100px";
    div1.style.height = "100px";
    div1.style.backgroundColor = "red";
    div1.addEventListener("click", function () {
        alert("Div1");
    });
    div2.style.width = "100px";
    div2.style.height = "100px";
    div2.style.backgroundColor = "green";
    div2.addEventListener("click", function () {
        alert("Div2");
    });
    div3.style.width = "100px";
    div3.style.height = "100px";
    div3.style.backgroundColor = "blue";
    div3.addEventListener("click", function () {
        alert("Div3");
    });

}


function TaskFour()
{

    var div1 = document.getElementById("task4-1");
    var div2 = document.getElementById("task4-2");
    var div3 = document.getElementById("task4-3");

    div1.style.width = "200px";
    div1.style.height = "200px";
    div1.style.backgroundColor = "red";
    div1.addEventListener("mouseover", function () {
        alert("Div1");
    });
    div1.addEventListener("mouseout", function () {
        this.parentElement.removeChild(this);
    });
    div2.style.width = "200px";
    div2.style.height = "200px";
    div2.style.backgroundColor = "green";
    div2.addEventListener("mouseover", function () {
        alert("Div2");
    });
    div2.addEventListener("mouseout", function () {
       this.parentElement.removeChild(this);
    });
    div3.style.width = "200px";
    div3.style.height = "200px";
    div3.style.backgroundColor = "blue";
    div3.addEventListener("mouseover", function () {
        alert("Div3");
    });
    div3.addEventListener("mouseout", function () {
        this.parentElement.removeChild(this);
    });

}




